CREATE DATABASE SalesAnalysisDB;

USE SalesAnalysisDB;

CREATE TABLE Customers(CustomerIndex INT PRIMARY KEY,CustomerName VARCHAR(150));

CREATE TABLE Region(RegionIndex INT PRIMARY KEY,City VARCHAR(100),Country VARCHAR(100),FullName VARCHAR(150));

CREATE TABLE Products (ProductIndex INT PRIMARY KEY,ProductName VARCHAR(150));

CREATE TABLE Budget2070 (ProductName VARCHAR(150) PRIMARY KEY,Budget2070 DECIMAL(12,2));

CREATE TABLE SalesOrders (
    OrderNumber NVARCHAR(50) PRIMARY KEY,
    OrderDate DATE,
    CustomerIndex INT,
    Channel NVARCHAR(50),
    CurrencyCode NVARCHAR(10),
    WarehouseCode NVARCHAR(50),
    DeliveryRegionIndex INT,
    ProductIndex INT,
    OrderQuantity INT,
    UnitPrice FLOAT,
    LineTotal FLOAT,
    TotalUnitCost FLOAT,

    FOREIGN KEY (CustomerIndex) REFERENCES Customers(CustomerIndex),
    FOREIGN KEY (DeliveryRegionIndex) REFERENCES Region(RegionIndex),
    FOREIGN KEY (ProductIndex) REFERENCES Products(ProductIndex));

  USE SalesAnalysisDB;

  SELECT * FROM dbo.Sales_Dataset;
  SELECT * FROM dbo.SQLBudget;
  SELECT * FROM dbo.SQLCustomer;
  SELECT * FROM dbo.SQLProduct;
  SELECT * FROM dbo.SQLRegion;


INSERT INTO Customers (CustomerIndex, CustomerName)
SELECT DISTINCT Customer_Index,Customer_Names FROM dbo.SQLCustomer;
 
SELECT * FROM dbo.Customers;

SELECT * FROM dbo.Products;

INSERT INTO Products(ProductIndex,ProductName)
SELECT DISTINCT "Index","Product_Name" FROM dbo.SQLProduct;

SELECT * FROM dbo.Region;


INSERT INTO Region(RegionIndex,City,Country,FullName)
SELECT DISTINCT "Index",City,Country,Full_Name FROM dbo.SQLRegion;

SELECT * FROM dbo.Budget2070; 


INSERT INTO Budget2070(ProductName,Budget2070)
SELECT DISTINCT Product_Name,_2017_Budgets FROM dbo.SQLBudget;

SELECT * FROM dbo.SalesOrders; 

INSERT INTO dbo.SalesOrders
(
    OrderNumber,
    OrderDate,
    CustomerIndex,
    Channel,
    CurrencyCode,
    WarehouseCode,
    DeliveryRegionIndex,
    ProductIndex,
    OrderQuantity,
    UnitPrice,
    LineTotal,
    TotalUnitCost
)
SELECT
    OrderNumber,
    OrderDate,
    Customer_Name_Index,
    Channel,
    Currency_Code,
    Warehouse_Code,
    Delivery_Region_Index,
    Product_Description_Index,
    Order_Quantity,
    Unit_Price,
    Line_Total,
    Total_Unit_Cost
FROM dbo.Sales_Dataset;

ALTER TABLE dbo.salesorders ADD Profit decimal(18,2);

UPDATE dbo.SalesOrders SET Profit = LineTotal-TotalUnitCost;

SELECT * FROM dbo.SalesOrders; 

SELECT 
    so.OrderNumber,
    c.CustomerName,
    p.ProductName,
    r.Country,
    so.LineTotal,
    so.Profit
FROM SalesOrders so
JOIN Customers c ON so.CustomerIndex = c.CustomerIndex
JOIN Products p ON so.ProductIndex = p.ProductIndex
JOIN Region r ON so.DeliveryRegionIndex = r.RegionIndex;